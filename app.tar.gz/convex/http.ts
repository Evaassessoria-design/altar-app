import { httpRouter } from "convex/server";
import { asaasWebhook } from "./asaasWebhook";

const http = httpRouter();

http.route({
  path: "/asaas-webhook",
  method: "POST",
  handler: asaasWebhook,
});

export default http;
