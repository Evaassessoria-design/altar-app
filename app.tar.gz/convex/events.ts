import { mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { ConvexError } from "convex/values";
import type { Id } from "./_generated/dataModel.d.ts";

async function getAuthUser(ctx: { auth: { getUserIdentity: () => Promise<{ tokenIdentifier: string } | null> }; db: { query: (table: string) => { withIndex: (index: string, q: (q: { eq: (field: string, value: string) => unknown }) => unknown) => { unique: () => Promise<{ _id: Id<"users">; role?: string } | null> } } } }) {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) throw new ConvexError({ message: "Não autenticado", code: "UNAUTHENTICATED" });
  const user = await ctx.db
    .query("users")
    .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
    .unique();
  if (!user) throw new ConvexError({ message: "Usuário não encontrado", code: "NOT_FOUND" });
  return user;
}

export const list = query({
  args: {
    filter: v.optional(v.union(v.literal("all"), v.literal("upcoming"), v.literal("completed"), v.literal("cancelled"))),
  },
  handler: async (ctx, args): Promise<Array<{
    _id: Id<"events">;
    _creationTime: number;
    userId: Id<"users">;
    name: string;
    type: string;
    date: string;
    location: string;
    clientName: string;
    clientPhone?: string;
    budget?: number;
    status: string;
    notes?: string;
  }>> => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return [];
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) return [];

    const all = await ctx.db
      .query("events")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .order("desc")
      .collect();

    const now = new Date().toISOString();
    const filter = args.filter ?? "all";

    if (filter === "upcoming") {
      return all.filter((e) => e.date >= now && e.status !== "cancelled" && e.status !== "completed");
    }
    if (filter === "completed") {
      return all.filter((e) => e.status === "completed");
    }
    if (filter === "cancelled") {
      return all.filter((e) => e.status === "cancelled");
    }
    return all;
  },
});

export const get = query({
  args: { id: v.id("events") },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) return null;
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) return null;
    const event = await ctx.db.get(args.id);
    if (!event || event.userId !== user._id) return null;
    return event;
  },
});

export const create = mutation({
  args: {
    name: v.string(),
    type: v.union(
      v.literal("wedding"),
      v.literal("corporate"),
      v.literal("birthday"),
      v.literal("debutante"),
      v.literal("baptism"),
      v.literal("other"),
    ),
    date: v.string(),
    location: v.string(),
    clientName: v.string(),
    clientPhone: v.optional(v.string()),
    budget: v.optional(v.number()),
    status: v.union(
      v.literal("planning"),
      v.literal("confirmed"),
      v.literal("in_progress"),
      v.literal("completed"),
      v.literal("cancelled"),
    ),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Não autenticado", code: "UNAUTHENTICATED" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ message: "Usuário não encontrado", code: "NOT_FOUND" });

    return await ctx.db.insert("events", {
      userId: user._id,
      ...args,
    });
  },
});

export const update = mutation({
  args: {
    id: v.id("events"),
    name: v.optional(v.string()),
    type: v.optional(v.union(
      v.literal("wedding"),
      v.literal("corporate"),
      v.literal("birthday"),
      v.literal("debutante"),
      v.literal("baptism"),
      v.literal("other"),
    )),
    date: v.optional(v.string()),
    location: v.optional(v.string()),
    clientName: v.optional(v.string()),
    clientPhone: v.optional(v.string()),
    budget: v.optional(v.number()),
    status: v.optional(v.union(
      v.literal("planning"),
      v.literal("confirmed"),
      v.literal("in_progress"),
      v.literal("completed"),
      v.literal("cancelled"),
    )),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Não autenticado", code: "UNAUTHENTICATED" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ message: "Usuário não encontrado", code: "NOT_FOUND" });

    const event = await ctx.db.get(args.id);
    if (!event || event.userId !== user._id) {
      throw new ConvexError({ message: "Evento não encontrado", code: "NOT_FOUND" });
    }

    const { id, ...patch } = args;
    await ctx.db.patch(id, patch);
  },
});

export const remove = mutation({
  args: { id: v.id("events") },
  handler: async (ctx, args) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) throw new ConvexError({ message: "Não autenticado", code: "UNAUTHENTICATED" });
    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) => q.eq("tokenIdentifier", identity.tokenIdentifier))
      .unique();
    if (!user) throw new ConvexError({ message: "Usuário não encontrado", code: "NOT_FOUND" });

    const event = await ctx.db.get(args.id);
    if (!event || event.userId !== user._id) {
      throw new ConvexError({ message: "Evento não encontrado", code: "NOT_FOUND" });
    }
    await ctx.db.delete(args.id);
  },
});
