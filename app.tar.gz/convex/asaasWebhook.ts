import { httpAction } from "./_generated/server";
import { internal } from "./_generated/api";

// Asaas sends events as POST to this endpoint.
// Webhook URL: https://kindly-goose-409.convex.site/asaas-webhook
// Asaas sends authToken inside the JSON body for validation.

export const asaasWebhook = httpAction(async (ctx, request) => {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return new Response("Invalid JSON", { status: 400 });
  }

  const payload = body as {
    event: string;
    authToken?: string;
    payment?: {
      customer: string;
      subscription?: string;
      status?: string;
      value?: number;
    };
    subscription?: {
      id: string;
      customer: string;
      status?: string;
    };
  };

  // Validate authToken from body (Asaas sends it here, not in headers)
  const webhookToken = process.env.ASAAS_WEBHOOK_TOKEN;
  if (webhookToken) {
    if (payload.authToken !== webhookToken) {
      return new Response("Unauthorized", { status: 401 });
    }
  }

  const eventType = payload.event;

  switch (eventType) {
    // Payment confirmed — activate or extend subscription
    case "PAYMENT_RECEIVED":
    case "PAYMENT_CONFIRMED": {
      const customerId = payload.payment?.customer;
      const subscriptionId = payload.payment?.subscription;
      if (!customerId) break;

      // Extend access by 1 month from now
      const expiresAt = new Date();
      expiresAt.setMonth(expiresAt.getMonth() + 1);

      await ctx.runMutation(internal.users.activateSubscriptionByCustomer, {
        asaasCustomerId: customerId,
        asaasSubscriptionId: subscriptionId,
        expiresAt: expiresAt.toISOString(),
      });
      break;
    }

    // Subscription fully cancelled/deleted in Asaas — remove access
    case "SUBSCRIPTION_DELETED": {
      const subscriptionId = payload.subscription?.id;
      if (!subscriptionId) break;
      await ctx.runMutation(internal.users.cancelSubscriptionBySubscriptionId, {
        asaasSubscriptionId: subscriptionId,
      });
      break;
    }

    // Refund processed — remove access
    case "PAYMENT_REFUNDED": {
      const customerId = payload.payment?.customer;
      if (!customerId) break;
      await ctx.runMutation(internal.users.cancelSubscriptionByCustomer, {
        asaasCustomerId: customerId,
      });
      break;
    }

    // PAYMENT_DELETED can be a single overdue charge deletion, not a full cancel
    // Only cancel if there is no active subscription linked
    case "PAYMENT_DELETED": {
      const subscriptionId = payload.payment?.subscription;
      // If linked to a subscription, let SUBSCRIPTION_DELETED handle cancellation
      if (subscriptionId) break;
      // Standalone payment deleted — cancel access
      const customerId = payload.payment?.customer;
      if (!customerId) break;
      await ctx.runMutation(internal.users.cancelSubscriptionByCustomer, {
        asaasCustomerId: customerId,
      });
      break;
    }

    default:
      // Ignore other events (PAYMENT_CREATED, PAYMENT_OVERDUE, etc.)
      break;
  }

  return new Response(JSON.stringify({ received: true }), {
    status: 200,
    headers: { "Content-Type": "application/json" },
  });
});
